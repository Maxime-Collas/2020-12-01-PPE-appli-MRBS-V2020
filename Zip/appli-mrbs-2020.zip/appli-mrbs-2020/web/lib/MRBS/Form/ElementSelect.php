<?php

namespace MRBS\Form;

class ElementSelect extends Element
{

  public function __construct()
  {
    parent::__construct('select');
  }
 
}