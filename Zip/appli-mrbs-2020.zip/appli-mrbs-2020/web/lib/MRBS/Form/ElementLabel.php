<?php

namespace MRBS\Form;

class ElementLabel extends Element
{

  public function __construct()
  {
    parent::__construct('label');
  }
 
}